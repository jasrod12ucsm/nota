

export interface CreateNotaCredito{
    codigo: String;
    precioNeto: number;
    motivo: String;
    codigoFactura: String;
    rucCliente: number;
}