export class ClientWithCreditNotesResponse {
  ruc: number;
  departamento: string;
  calle: string;
  avenida: string | null;
  distrito: string;
  ciudad: string;
  nombre: string;
  notaCreditoCodigo: string[];
}